CREATE TABLE `autocompletador` (
  `id` int(5) NOT NULL auto_increment,
  `nombre` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
